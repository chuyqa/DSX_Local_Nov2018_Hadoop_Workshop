from setuptools import setup, find_packages
 
setup(
    name = "quickens_demo_utils",
    version = "0.1",
    packages=['quickens_demo_utils']    
)

