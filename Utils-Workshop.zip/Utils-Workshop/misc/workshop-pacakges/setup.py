from setuptools import setup, find_packages

setup(
    name = "quicken_demo_utils",
    version = "0.1",
    packages=['quicken_demo_utils']    
)

